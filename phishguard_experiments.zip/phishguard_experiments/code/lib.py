import numpy as np, pandas as pd, time, json, warnings, hashlib
warnings.filterwarnings('ignore')
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_selection import SelectKBest, chi2
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score, average_precision_score, accuracy_score, matthews_corrcoef, confusion_matrix
from sklearn.model_selection import GroupShuffleSplit, train_test_split
MAXC=4000
MODELS=['MNB (word)','LR (word)','SVM (word)','LR (char)','SVM (word+char)','Random Forest','HistGB (SVD)','MLP (SVD)']

def load():
    a=pd.read_pickle('all.pkl')
    a=a[a.norm.str.split().str.len()>=3].copy()
    a['t']=a.text.str.slice(0,MAXC)
    return a.reset_index(drop=True)

def exact_dedupe(df):
    c=df.groupby('h').label.nunique(); bad=set(c[c>1].index)
    df=df[~df.h.isin(bad)]
    return df.drop_duplicates('h').reset_index(drop=True)

def _tfidf_nn(texts, ref_texts=None, thr=0.9, chunk=800):
    """near-duplicate pairs by cosine on word tf-idf. If ref given, return max sim of each text to ref."""
    v=TfidfVectorizer(min_df=2,max_features=100000,sublinear_tf=True,dtype=np.float32)
    if ref_texts is None:
        X=v.fit_transform(texts); R=X
    else:
        R=v.fit_transform(ref_texts); X=v.transform(texts)
    RT=R.T.tocsr()
    pairs=[]; mx=np.zeros(X.shape[0],dtype=np.float32)
    for s in range(0,X.shape[0],chunk):
        S=(X[s:s+chunk]@RT).toarray()
        if ref_texts is None:
            for i in range(S.shape[0]): S[i,s+i]=0
            ii,jj=np.where(S>=thr); pairs+= [(s+i,j) for i,j in zip(ii,jj) if s+i<j]
        else: mx[s:s+chunk]=S.max(axis=1)
    return pairs if ref_texts is None else mx

def near_groups(texts, thr=0.9):
    n=len(texts); parent=list(range(n))
    def f(x):
        while parent[x]!=x: parent[x]=parent[parent[x]]; x=parent[x]
        return x
    for i,j in _tfidf_nn(texts,None,thr):
        a,b=f(i),f(j)
        if a!=b: parent[a]=b
    return np.array([f(i) for i in range(n)])

def dedupe_near(df, thr=0.9):
    g=near_groups(df.t.tolist(),thr); df=df.copy(); df['grp']=g
    # drop groups with conflicting labels, keep first of each group
    c=df.groupby('grp').label.nunique(); bad=set(c[c>1].index)
    df=df[~df.grp.isin(bad)].drop_duplicates('grp').reset_index(drop=True)
    return df

def max_sim_to(test_texts, train_texts): return _tfidf_nn(test_texts, train_texts)

def featurize(tr, te_list):
    """fit on tr texts; return features for train and each test list"""
    out={}
    w=TfidfVectorizer(ngram_range=(1,2),min_df=2,max_features=100000,sublinear_tf=True,dtype=np.float32)
    Xw=w.fit_transform(tr); Tw=[w.transform(t) for t in te_list]
    c=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=3,max_features=150000,sublinear_tf=True,dtype=np.float32)
    Xc=c.fit_transform(tr); Tc=[c.transform(t) for t in te_list]
    svd=TruncatedSVD(200,random_state=0); Xs=svd.fit_transform(Xw); Ts=[svd.transform(t) for t in Tw]
    return dict(w=(Xw,Tw,w),c=(Xc,Tc,c),s=(Xs,Ts,svd))

def fit_models(F, y, seed=0, which=None):
    Xw,Tw,_=F['w']; Xc,Tc,_=F['c']; Xs,Ts,_=F['s']
    fitted={}
    def add(name,fn):
        if which and name not in which: return
        t=time.time(); fitted[name]=fn(); fitted[name]['fit_s']=time.time()-t
    def mnb():
        m=MultinomialNB(alpha=0.1).fit(Xw,y); return dict(m=m,feat='w',score=lambda X:m.predict_proba(X)[:,1],thr=0.5)
    def lrw():
        m=LogisticRegression(C=10,max_iter=1000,solver='liblinear').fit(Xw,y); return dict(m=m,feat='w',score=lambda X:m.predict_proba(X)[:,1],thr=0.5)
    def svmw():
        m=LinearSVC(C=0.5).fit(Xw,y); return dict(m=m,feat='w',score=lambda X:m.decision_function(X),thr=0.0)
    def lrc():
        m=LogisticRegression(C=10,max_iter=1000,solver='liblinear').fit(Xc,y); return dict(m=m,feat='c',score=lambda X:m.predict_proba(X)[:,1],thr=0.5)
    def svmwc():
        Xu=sparse.hstack([Xw,Xc]).tocsr(); m=LinearSVC(C=0.5).fit(Xu,y); return dict(m=m,feat='u',score=lambda X:m.decision_function(X),thr=0.0)
    def rf():
        sel=SelectKBest(chi2,k=min(20000,Xw.shape[1])).fit(Xw,y)
        m=RandomForestClassifier(n_estimators=200,n_jobs=2,random_state=seed,min_samples_leaf=1).fit(sel.transform(Xw),y)
        return dict(m=m,feat='w',pre=sel.transform,score=lambda X:m.predict_proba(X)[:,1],thr=0.5)
    def hgb():
        m=HistGradientBoostingClassifier(max_iter=200,learning_rate=0.1,random_state=seed).fit(Xs,y); return dict(m=m,feat='s',score=lambda X:m.predict_proba(X)[:,1],thr=0.5)
    def mlp():
        m=MLPClassifier((256,64),alpha=1e-3,early_stopping=True,max_iter=100,random_state=seed).fit(Xs,y); return dict(m=m,feat='s',score=lambda X:m.predict_proba(X)[:,1],thr=0.5)
    for n,f in zip(MODELS,[mnb,lrw,svmw,lrc,svmwc,rf,hgb,mlp]): add(n,f)
    return fitted

def predict(fitted, F, k):
    """scores for k-th test set"""
    res={}
    for n,f in fitted.items():
        if f['feat']=='w': X=F['w'][1][k]
        elif f['feat']=='c': X=F['c'][1][k]
        elif f['feat']=='s': X=F['s'][1][k]
        else: X=sparse.hstack([F['w'][1][k],F['c'][1][k]]).tocsr()
        if 'pre' in f: X=f['pre'](X)
        res[n]=f['score'](X)
    return res

def metrics(y,s,thr):
    p=(s>=thr).astype(int); tn,fp,fn,tp=confusion_matrix(y,p,labels=[0,1]).ravel()
    r=dict(n=len(y),pos=int(y.sum()),precision=precision_score(y,p,zero_division=0),recall=recall_score(y,p),f1=f1_score(y,p),acc=accuracy_score(y,p),mcc=matthews_corrcoef(y,p),fpr=fp/max(fp+tn,1),tp=int(tp),fp=int(fp),fn=int(fn),tn=int(tn))
    r['auc']=roc_auc_score(y,s) if 0<y.sum()<len(y) else float('nan')
    r['prauc']=average_precision_score(y,s) if 0<y.sum()<len(y) else float('nan')
    return r
