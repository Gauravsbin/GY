import numpy as np, pandas as pd
from lib import *
Bn=pd.read_pickle('out/Bn.pkl'); rows=[]; info=[]
ham=Bn[Bn.label==0].reset_index(drop=True)
dom=ham.sender_domain.where(ham.sender_domain!='unknown', pd.Series(np.arange(len(ham)).astype(str),index=ham.index))
gss=GroupShuffleSplit(1,test_size=0.3,random_state=0); tri,tei=next(gss.split(ham,groups=dom.values))
ham_tr,ham_te=ham.iloc[tri],ham.iloc[tei]
Bn['fam']=np.where(Bn.source=='spamassassin','spam',np.where(Bn.source=='nazario','phishing (Nazario)','advance-fee fraud'))
pos=Bn[Bn.label==1]
for fam in ['phishing (Nazario)','advance-fee fraud','spam']:
    train=pd.concat([ham_tr,pos[pos.fam!=fam]]).reset_index(drop=True)
    tpos=pos[pos.fam==fam]; ms=max_sim_to(tpos.t.tolist(),train.t.tolist()); tpos=tpos[ms<0.9]
    test=pd.concat([ham_te,tpos]).reset_index(drop=True)
    info.append(dict(held_out=fam,ntrain=len(train),test_ham=len(ham_te),test_pos=len(tpos),pos_removed_neardup=int((ms>=0.9).sum())))
    print(info[-1],flush=True)
    F=featurize(train.t.tolist(),[test.t.tolist()]); fit=fit_models(F,train.label.values,0); S=predict(fit,F,0)
    y=test.label.values
    for n,s in S.items():
        m=metrics(y,s,fit[n]['thr']); m.update(held_out=fam,model=n); rows.append(m)
    pd.DataFrame(rows).to_csv('out/loso_rows.csv',index=False); pd.DataFrame(info).to_csv('out/loso_info.csv',index=False)
print('DONE')
