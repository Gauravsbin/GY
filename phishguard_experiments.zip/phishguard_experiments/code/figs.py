import json, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#b8bdbf','xtick.color':'#52514e','ytick.color':'#0b0b0b','axes.labelcolor':'#52514e'})
S=json.load(open('out/stats.json')); MODELS=['MNB (word)','LR (word)','SVM (word)','LR (char)','SVM (word+char)','Random Forest','HistGB (SVD)','MLP (SVD)']
C='#2a78d6'; INK='#0b0b0b'; MUT='#52514e'
# Fig 1: F1 across four settings, small multiples
cr=S['cross']; w=S['within']
vals={'(a) Within corpus A':[w['A|group'][m]['f1'][0] for m in MODELS],
      '(b) Within corpus B':[w['B|group'][m]['f1'][0] for m in MODELS],
      '(c) Train on A, test on B':[cr['AtoB']['res'][m]['f1'] for m in MODELS],
      '(d) Train on B, test on A':[cr['BtoA']['res'][m]['f1'] for m in MODELS]}
fig,axs=plt.subplots(2,2,figsize=(7.2,6.2),dpi=200); axs=axs.ravel()
for ax,(t,v) in zip(axs,vals.items()):
    y=np.arange(len(MODELS))[::-1]; ax.barh(y,v,height=0.62,color=C)
    for yi,x in zip(y,v): ax.text(x+0.02,yi,f'{x:.3f}',va='center',fontsize=8,color=INK)
    ax.set_xlim(0,1.14); ax.set_xticks([0,0.5,1.0]); ax.set_title(t.replace(chr(10),' '),fontsize=8,color=INK,loc='left'); ax.grid(axis='x',color='#e3e5e6',lw=0.6); ax.set_axisbelow(True)
    ax.set_yticks(y); ax.set_yticklabels(MODELS,fontsize=8)
fig.supxlabel('F1 (phishing/spam = positive class)',fontsize=8,color=MUT); fig.tight_layout(); fig.savefig('out/fig_f1.png'); plt.close()
# Fig 2: leave-one-source-out recall
l=pd.read_csv('out/loso_rows.csv'); fams=['phishing (Nazario)','advance-fee fraud','spam']
fig,axs=plt.subplots(1,3,figsize=(7.2,3.4),sharey=True,dpi=200)
for ax,f in zip(axs,fams):
    g=l[l.held_out==f].set_index('model').loc[MODELS]; y=np.arange(len(MODELS))[::-1]
    ax.barh(y,g.recall.values,height=0.6,color=C)
    for yi,x in zip(y,g.recall.values): ax.text(x+0.015,yi,f'{x:.2f}',va='center',fontsize=8,color=INK)
    ax.set_xlim(0,1.12); ax.set_xticks([0,0.5,1.0]); ax.set_title(f'Held out: {f}',fontsize=8.5,color=INK,loc='left'); ax.grid(axis='x',color='#e3e5e6',lw=0.6); ax.set_axisbelow(True)
axs[0].set_yticks(np.arange(len(MODELS))[::-1]); axs[0].set_yticklabels(MODELS)
fig.supxlabel('Recall on the held-out threat type (false-positive rate on held-out legitimate mail: 0.2% to 4.4%)',fontsize=8,color=MUT); fig.tight_layout(); fig.savefig('out/fig_loso.png'); plt.close()
# Fig 3: latency vs F1 (cross-corpus mean of A->B and B->A F1 is misleading; use B-pool grouped F1 and A->B? use mean of four settings)
lat=pd.read_csv('out/latency.csv').set_index('model')
mean=[np.mean([vals[k][i] for k in vals]) for i in range(len(MODELS))]
fig,ax=plt.subplots(figsize=(6.2,3.6),dpi=200)
ax.scatter([lat.loc[m,'p50'] for m in MODELS],mean,s=46,color=C,edgecolor='white',linewidth=1.5,zorder=3)
off={'MNB (word)':(8,-3),'LR (word)':(8,-12),'SVM (word)':(2,9),'LR (char)':(6,-4),'SVM (word+char)':(6,4),'Random Forest':(-6,-14),'HistGB (SVD)':(6,-12),'MLP (SVD)':(-8,8)}
for m,v in zip(MODELS,mean):
    dx,dy=off[m]; ax.annotate(m,(lat.loc[m,'p50'],v),xytext=(dx,dy),textcoords='offset points',fontsize=8,color=INK,ha='left' if dx>2 else ('center' if dx>=0 else 'right'))
ax.set_xscale('log'); ax.set_xlabel('Median single-email latency, ms (log scale, includes feature extraction)'); ax.set_ylabel('Mean F1 over the four settings of Figure 1')
ax.grid(color='#e3e5e6',lw=0.6); ax.set_axisbelow(True); ax.set_xlim(0.5,150); fig.tight_layout(); fig.savefig('out/fig_lat.png'); plt.close()
print('ok',[round(x,3) for x in mean])
