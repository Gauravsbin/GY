import pandas as pd, numpy as np, time
from lib import *
a=load(); print(len(a))
t=time.time()
A=a[a.source=='phishing_email_csv'].copy(); B=a[a.source!='phishing_email_csv'].copy()
print('A',len(A),'B',len(B))
Ae=exact_dedupe(A); Be=exact_dedupe(B); print('exact dedupe A',len(Ae),'B',len(Be), time.time()-t)
Ae['pool']='A'; Be['pool']='B'
An=dedupe_near(Ae,0.9); print('near dedupe A',len(An), time.time()-t)
Bn=dedupe_near(Be,0.9); print('near dedupe B',len(Bn), time.time()-t)
for n,d in [('Ae',Ae),('An',An),('Be',Be),('Bn',Bn)]: d.to_pickle(f'out/{n}.pkl')
print(An.label.value_counts().to_dict(), Bn.groupby(['source','label']).size().to_dict())
