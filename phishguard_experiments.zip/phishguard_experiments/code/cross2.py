import time, numpy as np, pandas as pd
from lib import *
Ae=pd.read_pickle('out/Ae.pkl'); An=pd.read_pickle('out/An.pkl'); Be=pd.read_pickle('out/Be.pkl'); Bn=pd.read_pickle('out/Bn.pkl')
rows=[]; info=[]
def run(name, train, test_full):
    ms=max_sim_to(test_full.t.tolist(), train.t.tolist())
    test=test_full[ms<0.9].reset_index(drop=True)
    info.append(dict(exp=name,ntrain=len(train),ntest_before=len(test_full),ntest_after=len(test),removed_neardup=len(test_full)-len(test),test_pos=int(test.label.sum()),train_pos=int(train.label.sum())))
    print(info[-1],flush=True)
    F=featurize(train.t.tolist(),[test.t.tolist()]); fit=fit_models(F,train.label.values,0); S=predict(fit,F,0)
    y=test.label.values
    import pickle; pickle.dump(dict(y=y,S=S,thr={n:fit[n]['thr'] for n in fit},src=test.source.values),open(f'out/preds_{name.replace("->","to")}.pkl','wb'))
    for n,s in S.items():
        thr=fit[n]['thr']; p=(s>=thr).astype(int)
        m=metrics(y,s,thr); m.update(exp=name,model=n,group='ALL'); rows.append(m)
        if name=='A->B':
            for (src,lab),idx in test.groupby(['source','label']).groups.items():
                idx=np.array(idx); acc=(p[idx]==lab).mean()
                rows.append(dict(exp=name,model=n,group=f'{src}|{"phish/spam" if lab else "ham"}',n=len(idx),rate=acc))  # recall for positives, specificity for ham
    return F,fit,test
F,fit,test=run('A->B',An,Be)
F2,fit2,test2=run('B->A',Bn,Ae)
pd.DataFrame(rows).to_csv('out/cross_rows2.csv',index=False); pd.DataFrame(info).to_csv('out/cross_info2.csv',index=False)
print('DONE')
