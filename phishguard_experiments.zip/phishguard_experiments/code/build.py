import os, re, sys, email, html, hashlib, pandas as pd, numpy as np
from email import policy
D='data'; U='/root/.claude/uploads/59213544-b823-5021-b3cb-5bdeba7c66b1'
TAG=re.compile(r'<[^>]+>'); WS=re.compile(r'\s+')
def clean(t):
    t=html.unescape(str(t)); t=re.sub(r'(?is)<(script|style).*?</\1>',' ',t); t=TAG.sub(' ',t)
    return WS.sub(' ',t).strip()
def parse_dir(path, label, source):
    rows=[]
    for f in sorted(os.listdir(path)):
        if f=='cmds': continue
        raw=open(os.path.join(path,f),'rb').read()
        try: m=email.message_from_bytes(raw, policy=policy.default)
        except Exception: continue
        body=''
        try:
            b=m.get_body(preferencelist=('plain','html'))
            body=b.get_content() if b else ''
        except Exception:
            body=''
        if not body:
            try: body=raw.decode('latin-1')
            except Exception: body=''
        frm=str(m.get('From','')); subj=str(m.get('Subject',''))
        dom=re.search(r'@([\w\.-]+)',frm); 
        rows.append(dict(source=source,subject=clean(subj),body=clean(body),sender_domain=(dom.group(1).lower() if dom else 'unknown'),label=label,file=f))
    return pd.DataFrame(rows)
sa=pd.concat([
  parse_dir(f'{D}/spam2/spam_2',1,'spamassassin'),
  parse_dir(f'{D}/easyham/easy_ham',0,'spamassassin'),
  parse_dir(f'{D}/hardham/hard_ham',0,'spamassassin')],ignore_index=True)
sa['sub']=sa.file.map(lambda f:'x'); 
def load_csv(f,source):
    d=pd.read_csv(f)
    dom=d['sender'].astype(str).str.extract(r'@([\w\.-]+)')[0].str.lower().fillna('unknown')
    return pd.DataFrame(dict(source=source,subject=d['subject'].fillna('').map(clean),body=d['body'].fillna('').map(clean),sender_domain=dom,label=d['label'].astype(int)))
naz=load_csv(f'{U}/f4472cb6-Nazario.csv','nazario'); nig=load_csv(f'{U}/d75b9fe4-Nigerian_5.csv','nigerian')
pe=pd.read_csv(f'{D}/archive/Phishing_Email.csv')
pe=pd.DataFrame(dict(source='phishing_email_csv',subject='',body=pe['Email Text'].fillna('').map(clean),sender_domain='unknown',label=(pe['Email Type']=='Phishing Email').astype(int)))
sa=sa.drop(columns=['file','sub'])
allx=pd.concat([sa,naz,nig,pe],ignore_index=True)
allx['text']=(allx.subject+' '+allx.body).str.strip()
allx['norm']=allx.text.str.lower().str.replace(r'[^a-z0-9]+',' ',regex=True).str.strip()
allx['h']=allx.norm.map(lambda s:hashlib.md5(s[:3000].encode()).hexdigest())
allx['nwords']=allx.norm.str.split().str.len()
allx.to_pickle('exp/all.pkl')
print(allx.groupby(['source','label']).size().unstack(fill_value=0))
print(allx.groupby('source').nwords.describe()[['mean','50%','min','max']])
print('empty text',(allx.nwords==0).sum())
