#!/bin/bash
for pool in A B; do for mode in random group; do for seed in 0 1 2; do
  f=out/split_${pool}_${mode}_${seed}.csv; [ -f $f ] || python3 split_exp.py $pool $mode $seed >> out/splits.log 2>&1
done; done; done
echo DONE >> out/splits.log
