import sys, json, time, numpy as np, pandas as pd
from lib import *
pool, mode, seed = sys.argv[1], sys.argv[2], int(sys.argv[3])   # pool A|B ; mode random|group
df=pd.read_pickle(f'out/{pool}e.pkl')
if mode=='group' or 'grp' not in df:
    pass
if 'grp' not in df: df['grp']=near_groups(df.t.tolist(),0.9)
y=df.label.values
if mode=='random':
    tr,te=train_test_split(np.arange(len(df)),test_size=0.2,stratify=y,random_state=seed)
else:
    gss=GroupShuffleSplit(1,test_size=0.2,random_state=seed); tr,te=next(gss.split(df,y,groups=df.grp.values))
t0=time.time()
F=featurize(df.t.values[tr].tolist(),[df.t.values[te].tolist()]); t1=time.time()
fit=fit_models(F,y[tr],seed); t2=time.time()
S=predict(fit,F,0)
rows=[]
for n,s in S.items():
    m=metrics(y[te],s,fit[n]['thr']); m.update(model=n,pool=pool,mode=mode,seed=seed,fit_s=fit[n]['fit_s']); rows.append(m)
# share of test docs having a near-dup (>=0.9) in train (leakage indicator)
ms=max_sim_to(df.t.values[te].tolist(), df.t.values[tr].tolist()); 
for r in rows: r['test_neardup_frac']=float((ms>=0.9).mean()); r['ntrain']=len(tr)
pd.DataFrame(rows).to_csv(f'out/split_{pool}_{mode}_{seed}.csv',index=False)
print(pool,mode,seed,'featurize',round(t1-t0),'fit',round(t2-t1),'total',round(time.time()-t0)); print(pd.DataFrame(rows)[['model','f1','recall','precision','fpr','auc','fit_s']].round(4).to_string())
