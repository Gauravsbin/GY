import pickle, json, numpy as np, pandas as pd, glob
from scipy.stats import binomtest
MODELS=['MNB (word)','LR (word)','SVM (word)','LR (char)','SVM (word+char)','Random Forest','HistGB (SVD)','MLP (SVD)']
out={}
# within-corpus mean/sd
d=pd.concat([pd.read_csv(f) for f in glob.glob('out/split_*.csv')])
w={}
for (pool,mode),g in d.groupby(['pool','mode']):
    gg=g.groupby('model')[['f1','recall','precision','fpr','auc','test_neardup_frac']].agg(['mean','std'])
    w[f'{pool}|{mode}']={m:{k:[float(gg.loc[m,(k,'mean')]),float(gg.loc[m,(k,'std')])] for k in ['f1','recall','precision','fpr','auc','test_neardup_frac']} for m in MODELS}
out['within']=w
# cross-corpus bootstrap + mcnemar
rng=np.random.default_rng(0); cr={}
for ex in ['AtoB','BtoA']:
    P=pickle.load(open(f'out/preds_{ex}.pkl','rb')); y=P['y']; n=len(y)
    pred={m:(P['S'][m]>=P['thr'][m]).astype(int) for m in MODELS}
    idx=[rng.integers(0,n,n) for _ in range(500)]
    def f1(p,yy):
        tp=((p==1)&(yy==1)).sum(); fp=((p==1)&(yy==0)).sum(); fn=((p==0)&(yy==1)).sum(); return 2*tp/max(2*tp+fp+fn,1)
    res={}
    for m in MODELS:
        b=[f1(pred[m][i],y[i]) for i in idx]; res[m]=dict(f1=f1(pred[m],y),lo=float(np.percentile(b,2.5)),hi=float(np.percentile(b,97.5)))
    best=max(MODELS,key=lambda m:res[m]['f1']); mc={}
    for m in MODELS:
        if m==best: continue
        a=(pred[best]==y); b=(pred[m]==y); n01=int((a&~b).sum()); n10=int((~a&b).sum())
        mc[m]=dict(best_only=n01,other_only=n10,p=float(binomtest(min(n01,n10),n01+n10,0.5).pvalue) if n01+n10 else 1.0)
    cr[ex]=dict(res=res,best=best,mcnemar=mc,n=int(n))
out['cross']=cr
json.dump(out,open('out/stats.json','w'),indent=1)
for ex in cr:
    print(ex,'best',cr[ex]['best']); 
    for m in MODELS: print(' ',m,round(cr[ex]['res'][m]['f1'],4),round(cr[ex]['res'][m]['lo'],4),round(cr[ex]['res'][m]['hi'],4),cr[ex]['mcnemar'].get(m))
