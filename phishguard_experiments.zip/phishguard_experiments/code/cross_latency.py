import time, numpy as np, pandas as pd
from lib import *
Ae=pd.read_pickle('out/Ae.pkl'); An=pd.read_pickle('out/An.pkl'); Be=pd.read_pickle('out/Be.pkl'); Bn=pd.read_pickle('out/Bn.pkl')
rows=[]; info=[]
def run(name, train, test_full):
    ms=max_sim_to(test_full.t.tolist(), train.t.tolist())
    test=test_full[ms<0.9].reset_index(drop=True)
    info.append(dict(exp=name,ntrain=len(train),ntest_before=len(test_full),ntest_after=len(test),removed_neardup=len(test_full)-len(test),test_pos=int(test.label.sum()),train_pos=int(train.label.sum())))
    print(info[-1],flush=True)
    F=featurize(train.t.tolist(),[test.t.tolist()]); fit=fit_models(F,train.label.values,0); S=predict(fit,F,0)
    y=test.label.values
    for n,s in S.items():
        thr=fit[n]['thr']; p=(s>=thr).astype(int)
        m=metrics(y,s,thr); m.update(exp=name,model=n,group='ALL'); rows.append(m)
        if name=='A->B':
            for (src,lab),idx in test.groupby(['source','label']).groups.items():
                idx=np.array(idx); acc=(p[idx]==lab).mean()
                rows.append(dict(exp=name,model=n,group=f'{src}|{"phish/spam" if lab else "ham"}',n=len(idx),rate=acc))  # recall for positives, specificity for ham
    return F,fit,test
F,fit,test=run('A->B',An,Be)
pd.DataFrame(rows).to_csv('out/cross_rows.csv',index=False); pd.DataFrame(info).to_csv('out/cross_info.csv',index=False)
# latency on models trained on An, 100 test docs, single email, end-to-end incl. feature extraction
rng=np.random.default_rng(0); docs=test.t.sample(100,random_state=0).tolist()
w=F['w'][2]; c=F['c'][2]; svd=F['s'][2]
def lat(name):
    f=fit[name]; ts=[]
    for d in docs+docs[:5]:
        t=time.perf_counter()
        if f['feat']=='w': X=w.transform([d])
        elif f['feat']=='c': X=c.transform([d])
        elif f['feat']=='s': X=svd.transform(w.transform([d]))
        else: X=sparse.hstack([w.transform([d]),c.transform([d])]).tocsr()
        if 'pre' in f: X=f['pre'](X)
        f['score'](X); ts.append((time.perf_counter()-t)*1000)
    ts=np.array(ts[5:]); return dict(model=name,p50=np.percentile(ts,50),p95=np.percentile(ts,95),p99=np.percentile(ts,99))
pd.DataFrame([lat(n) for n in fit]).to_csv('out/latency.csv',index=False); print(pd.read_csv('out/latency.csv').round(2))
F2,fit2,test2=run('B->A',Bn,Ae)
pd.DataFrame(rows).to_csv('out/cross_rows.csv',index=False); pd.DataFrame(info).to_csv('out/cross_info.csv',index=False)
print('DONE')
