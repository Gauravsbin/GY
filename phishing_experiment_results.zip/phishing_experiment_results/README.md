# Phishing email baseline experiment results

## Dataset
Input archive: archive.zip containing Phishing_Email.csv.
Rows loaded: 18650.
Rows with non-empty email text: 18631.
After whitespace/lowercase normalized exact deduplication and removal of the single conflicting-label duplicate group: 17513.
Class labels: Safe Email=0, Phishing Email=1.
Final class counts: safe=10977, phishing=6536.

## Protocol
One stratified split with random seed 42: train=12259, validation=2627, test=2627. The validation split was created but was not used for hyperparameter selection. TF-IDF word unigrams/bigrams (min_df=2, max_features=150000, sublinear_tf=True) + Logistic Regression (C=4, liblinear, max_iter=500). Decision threshold 0.5. Bootstrap 95% confidence intervals are percentile intervals with 1000 resamples on the held-out test set.

## Test results
Precision: 0.9875 (95% CI 0.9803-0.9940)
Recall: 0.9694 (95% CI 0.9581-0.9794)
F1: 0.9784 (95% CI 0.9718-0.9845)
ROC-AUC: 0.9983 (95% CI 0.9971-0.9992)
PR-AUC: 0.9965
Confusion matrix in TN, FP, FN, TP order: [1635, 12, 30, 950].

## Latency
Measured in this runtime, including TF-IDF transformation and classification, 100 individual test messages after 5 warm-up messages:
P50=0.537 ms, P95=1.166 ms, P99=1.574 ms.
Batch throughput from prediction over 2627 test messages: 2900.5 emails/s. This batch throughput is not the same as single-email end-to-end latency.

## Critical limitations
- This is a real measured baseline, not transformer fine-tuning.
- Exact normalized duplicates were removed before the split; near-duplicate, sender-domain, campaign, and source-aware grouping were NOT performed. Therefore do not claim fully leakage-free/campaign-independent generalization.
- Dataset provenance and source composition need to be checked against the dataset card before publication.
- The validation set was reserved but not used for model selection.
- Latency is specific to this execution environment and should be re-measured on the intended deployment hardware.
- This does not measure Gmail add-on end-to-end latency or live inbox accuracy.
- Only one split/seed was run. Run multiple seeds and a separate external corpus before claiming robust performance.


## Additional measured classical baselines

                           Model  Precision   Recall       F1  Accuracy  ROC-AUC   PR-AUC         TN_FP_FN_TP
    TF-IDF + Logistic Regression   0.987526 0.969388 0.978373  0.984012 0.998266 0.996549 [1635, 12, 30, 950]
TF-IDF + Multinomial Naive Bayes   0.992333 0.924490 0.957211  0.969166 0.997933 0.996665  [1640, 7, 74, 906]
             TF-IDF + Linear SVM   0.988577 0.971429 0.979928  0.985154 0.998658 0.997282 [1636, 11, 28, 952]

## Latency measurements by model

                           Model           Format  P50 (ms)  P95 (ms)  P99 (ms)       F1
    TF-IDF + Logistic Regression scikit-learn CPU  0.503643  1.324083  1.947564 0.978373
TF-IDF + Multinomial Naive Bayes scikit-learn CPU  1.231883  1.934749  2.774685 0.957211
             TF-IDF + Linear SVM scikit-learn CPU  0.454178  1.225090  2.165220 0.979928

## Reproducibility caveats

Only one stratified split (seed 42) was used for this run. Exact normalized duplicates were removed before splitting, but no near-duplicate/campaign/sender-domain grouping was applied. Treat these as preliminary in-dataset results, not proof of source-independent generalization. The validation split was reserved but not used for tuning. No transformer model was fine-tuned in this run.
